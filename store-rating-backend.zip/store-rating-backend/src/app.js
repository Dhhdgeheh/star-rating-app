const express = require('express');
const cors = require('cors');
require('dotenv').config();
const storeRoutes = require('./routes/storeRoutes');
const ratingRoutes = require('./routes/ratingRoutes');
const storeOwnerRoutes = require('./routes/storeOwnerRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();

// Middleware
app.use(cors({origin: 'http://localhost:5173', // Vite default port
  credentials: true}));
app.use(express.json());

// Import Auth Routes
const authRoutes = require('./routes/authRoutes');

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/stores', storeRoutes);
app.use('/api/ratings', ratingRoutes);
app.use('/api/store-owner', storeOwnerRoutes);
app.use('/api/admin', adminRoutes);
app.use('/auth', require('./routes/authRoutes'));


// Test Route
app.get('/', (req, res) => {
  res.send('🎉 Store Rating API is working');
});

module.exports = app;
